const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');
const multer = require('multer');
const cron = require('node-cron');
const path = require('path');
const fs = require('fs');
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const initSqlJs = require('sql.js');

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'fantasygame_secret_2024_baku_change_me';

// CONFIG
const CONFIG = {
  BUSINESS_EMAIL: process.env.BUSINESS_EMAIL || 'YOUR_EMAIL@gmail.com',
  BUSINESS_EMAIL_PASSWORD: process.env.BUSINESS_EMAIL_PASSWORD || 'YOUR_APP_PASSWORD',
  STEAM_IMAP_EMAIL: process.env.STEAM_IMAP_EMAIL || 'YOUR_STEAM_EMAIL@gmail.com',
  STEAM_IMAP_PASSWORD: process.env.STEAM_IMAP_PASSWORD || 'YOUR_STEAM_APP_PASSWORD',
  WHATSAPP_NUMBER: process.env.WHATSAPP_NUMBER || '994505786977',
  BANK_NAME: process.env.BANK_NAME || 'Kapital Bank',
  CARD_NUMBER: process.env.CARD_NUMBER || '4169 XXXX XXXX XXXX',
  CARD_OWNER: process.env.CARD_OWNER || 'AD SOYAD',
};

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, '../frontend/public')));

if (!fs.existsSync(path.join(__dirname, 'uploads'))) {
  fs.mkdirSync(path.join(__dirname, 'uploads'), { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

const loginAttempts = {};
const rateLimit = (req, res, next) => {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  if (!loginAttempts[ip]) loginAttempts[ip] = { count: 0, lastAttempt: now };
  if (now - loginAttempts[ip].lastAttempt > 15 * 60 * 1000) loginAttempts[ip] = { count: 0, lastAttempt: now };
  if (loginAttempts[ip].count >= 5) return res.status(429).json({ error: 'Çox cəhd. 15 dəqiqə gözləyin.' });
  loginAttempts[ip].count++;
  loginAttempts[ip].lastAttempt = now;
  next();
};

// DB
let db;
const DB_PATH = path.join(__dirname, 'fantasygame.db');

function saveDb() {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function run(sql, params = []) {
  db.run(sql, params);
  saveDb();
}

function get(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    return row;
  }
  stmt.free();
  return null;
}

function all(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

async function initDb() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL, role TEXT DEFAULT 'user', balance REAL DEFAULT 0,
    lang TEXT DEFAULT 'az', theme TEXT DEFAULT 'dark', created_at TEXT DEFAULT (datetime('now'))
  )`);
  run(`CREATE TABLE IF NOT EXISTS games (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, description_az TEXT, description_en TEXT,
    description_ru TEXT, price REAL NOT NULL, rental_price_per_day REAL, genre TEXT,
    image_url TEXT, rating REAL DEFAULT 0, stock INTEGER DEFAULT 1,
    type TEXT DEFAULT 'both', is_active INTEGER DEFAULT 1, created_at TEXT DEFAULT (datetime('now'))
  )`);
  run(`CREATE TABLE IF NOT EXISTS steam_accounts (
    id TEXT PRIMARY KEY, account_name TEXT NOT NULL, steam_username TEXT NOT NULL,
    steam_password TEXT NOT NULL, games_list TEXT, rental_price_per_day REAL NOT NULL,
    is_available INTEGER DEFAULT 1, description_az TEXT, description_en TEXT, description_ru TEXT,
    current_renter_id TEXT, rental_end_time TEXT, created_at TEXT DEFAULT (datetime('now'))
  )`);
  run(`CREATE TABLE IF NOT EXISTS customer_codes (
    id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, user_id TEXT, account_id TEXT,
    game_id TEXT, type TEXT NOT NULL, rental_days INTEGER,
    rental_start TEXT DEFAULT (datetime('now')), rental_end TEXT, is_used INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  )`);
  run(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, type TEXT NOT NULL, item_id TEXT NOT NULL,
    item_title TEXT NOT NULL, amount REAL NOT NULL, rental_days INTEGER,
    status TEXT DEFAULT 'completed', created_at TEXT DEFAULT (datetime('now'))
  )`);
  run(`CREATE TABLE IF NOT EXISTS cart (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, item_id TEXT NOT NULL,
    item_type TEXT NOT NULL, rental_days INTEGER DEFAULT 1
  )`);
  run(`CREATE TABLE IF NOT EXISTS balance_requests (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, amount REAL NOT NULL,
    receipt_file TEXT, status TEXT DEFAULT 'pending', admin_note TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  )`);
  run(`CREATE TABLE IF NOT EXISTS steam_codes_cache (
    id TEXT PRIMARY KEY, code TEXT NOT NULL, account_id TEXT,
    received_at TEXT DEFAULT (datetime('now')), is_delivered INTEGER DEFAULT 0
  )`);

  const adminExists = get('SELECT id FROM users WHERE role=?', ['admin']);
  if (!adminExists) {
    const hashed = bcrypt.hashSync('admin123', 10);
    run('INSERT INTO users VALUES (?,?,?,?,?,?,?,?,datetime("now"))',
      [uuidv4(), 'admin', CONFIG.BUSINESS_EMAIL, hashed, 'admin', 99999, 'az', 'dark']);
  }
  console.log('✅ Databaza hazır');
}

// Email
const getTransporter = () => nodemailer.createTransport({
  service: 'gmail',
  auth: { user: CONFIG.BUSINESS_EMAIL, pass: CONFIG.BUSINESS_EMAIL_PASSWORD }
});

const sendEmail = async (to, subject, html) => {
  try {
    await getTransporter().sendMail({ from: `Fantasy Game Store <${CONFIG.BUSINESS_EMAIL}>`, to, subject, html });
  } catch (e) { console.log('Email xətası:', e.message); }
};

const emailTemplate = (title, content) => `<!DOCTYPE html>
<html><head><style>
body{font-family:Arial,sans-serif;background:#0a0a0f;color:#fff;margin:0;padding:20px}
.container{max-width:600px;margin:0 auto;background:#12121a;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#1a0a0a,#0a0a1a);padding:30px;text-align:center;border-bottom:2px solid #cc0000}
.header h1{color:#cc0000;margin:0;font-size:24px}.content{padding:30px}
.footer{text-align:center;padding:20px;color:#666;font-size:12px;border-top:1px solid #222}
.code-box{background:#1a1a2e;border:2px solid #cc0000;border-radius:8px;padding:20px;text-align:center;font-size:28px;font-weight:bold;color:#ff4444;letter-spacing:4px;margin:20px 0}
.warning{background:#2a1a00;border-left:4px solid #ff8800;padding:15px;border-radius:4px;margin:15px 0}
</style></head><body>
<div class="container">
<div class="header"><h1>🎮 Fantasy Game Store</h1><p style="color:#999;margin:5px 0 0">${title}</p></div>
<div class="content">${content}</div>
<div class="footer"><p>Fantasy Game Store © 2024 | Baku, Azerbaijan</p><p>WhatsApp: +${CONFIG.WHATSAPP_NUMBER}</p></div>
</div></body></html>`;

// IMAP
const fetchSteamCode = (accountId) => new Promise((resolve) => {
  const imap = new Imap({
    user: CONFIG.STEAM_IMAP_EMAIL, password: CONFIG.STEAM_IMAP_PASSWORD,
    host: 'imap.gmail.com', port: 993, tls: true,
    tlsOptions: { rejectUnauthorized: false }
  });
  imap.once('ready', () => {
    imap.openBox('INBOX', false, (err) => {
      if (err) { imap.end(); return resolve(null); }
      imap.search(['UNSEEN', ['FROM', 'noreply@steampowered.com']], (err, results) => {
        if (err || !results.length) { imap.end(); return resolve(null); }
        const fetch = imap.fetch(results.slice(-1), { bodies: '' });
        let code = null;
        fetch.on('message', (msg) => {
          msg.on('body', (stream) => {
            simpleParser(stream, (err, parsed) => {
              if (err) return;
              const text = parsed.text || '';
              const match = text.match(/\b([A-Z0-9]{5})\b/);
              if (match) {
                code = match[1];
                run('INSERT INTO steam_codes_cache VALUES (?,?,?,datetime("now"),0)', [uuidv4(), code, accountId]);
              }
            });
          });
        });
        fetch.once('end', () => { imap.end(); setTimeout(() => resolve(code), 1000); });
      });
    });
  });
  imap.once('error', () => resolve(null));
  imap.connect();
});

// Auth middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token tələb olunur' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Token etibarsızdır' }); }
};

const adminAuth = (req, res, next) => {
  auth(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin icazəsi tələb olunur' });
    next();
  });
};

// ===== ROUTES =====

app.post('/api/register', rateLimit, (req, res) => {
  const { username, email, password, lang } = req.body;
  if (!username || !email || !password) return res.status(400).json({ error: 'Bütün sahələri doldurun' });
  if (password.length < 6) return res.status(400).json({ error: 'Şifrə minimum 6 simvol olmalıdır' });
  try {
    const hashed = bcrypt.hashSync(password, 10);
    const id = uuidv4();
    run('INSERT INTO users VALUES (?,?,?,?,?,?,?,?,datetime("now"))',
      [id, username, email, hashed, 'user', 0, lang || 'az', 'dark']);
    const token = jwt.sign({ id, username, role: 'user' }, JWT_SECRET, { expiresIn: '7d' });
    sendEmail(email, 'Fantasy Game Store - Xoş Gəldiniz!', emailTemplate('Qeydiyyat Uğurlu',
      `<h2>Salam, ${username}! 🎮</h2><p>Fantasy Game Store-a xoş gəldiniz!</p>`));
    res.json({ token, user: { id, username, email, role: 'user', balance: 0, lang: lang || 'az', theme: 'dark' } });
  } catch (e) { res.status(400).json({ error: 'Bu istifadəçi adı və ya email artıq mövcuddur' }); }
});

app.post('/api/login', rateLimit, (req, res) => {
  const { email, password } = req.body;
  const user = get('SELECT * FROM users WHERE email=?', [email]);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Email və ya şifrə yanlışdır' });
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, email: user.email, role: user.role, balance: parseFloat(user.balance) || 0, lang: user.lang, theme: user.theme } });
});

app.get('/api/me', auth, (req, res) => {
  const user = get('SELECT id,username,email,role,balance,lang,theme,created_at FROM users WHERE id=?', [req.user.id]);
  if (user) user.balance = parseFloat(user.balance) || 0;
  res.json(user);
});

app.put('/api/me/settings', auth, (req, res) => {
  const { lang, theme } = req.body;
  run('UPDATE users SET lang=?, theme=? WHERE id=?', [lang, theme, req.user.id]);
  res.json({ message: 'Saxlanıldı' });
});

app.get('/api/games', (req, res) => {
  const { genre, type, search } = req.query;
  let q = 'SELECT * FROM games WHERE is_active=1';
  const params = [];
  if (genre) { q += ' AND genre=?'; params.push(genre); }
  if (type === 'sale') q += ' AND (type="sale" OR type="both")';
  if (type === 'rental') q += ' AND (type="rental" OR type="both")';
  if (search) { q += ' AND title LIKE ?'; params.push('%' + search + '%'); }
  res.json(all(q, params));
});

app.get('/api/games/:id', (req, res) => {
  const game = get('SELECT * FROM games WHERE id=?', [req.params.id]);
  if (!game) return res.status(404).json({ error: 'Tapılmadı' });
  res.json(game);
});

app.post('/api/games', adminAuth, (req, res) => {
  const { title, description_az, description_en, description_ru, price, rental_price_per_day, genre, image_url, rating, stock, type } = req.body;
  const id = uuidv4();
  run('INSERT INTO games VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,datetime("now"))',
    [id, title, description_az||'', description_en||'', description_ru||'', price||0, rental_price_per_day||0, genre||'', image_url||'', rating||0, stock||1, type||'both', 1]);
  res.json({ id, message: 'Oyun əlavə edildi' });
});

app.put('/api/games/:id', adminAuth, (req, res) => {
  const { title, description_az, description_en, description_ru, price, rental_price_per_day, genre, image_url, stock, is_active } = req.body;
  run('UPDATE games SET title=?,description_az=?,description_en=?,description_ru=?,price=?,rental_price_per_day=?,genre=?,image_url=?,stock=?,is_active=? WHERE id=?',
    [title, description_az, description_en, description_ru, price, rental_price_per_day, genre, image_url, stock, is_active, req.params.id]);
  res.json({ message: 'Yeniləndi' });
});

app.delete('/api/games/:id', adminAuth, (req, res) => {
  run('UPDATE games SET is_active=0 WHERE id=?', [req.params.id]);
  res.json({ message: 'Silindi' });
});

app.get('/api/accounts', (req, res) => {
  res.json(all('SELECT id,account_name,games_list,rental_price_per_day,is_available,description_az,description_en,description_ru FROM steam_accounts WHERE is_available=1'));
});

app.post('/api/accounts', adminAuth, (req, res) => {
  const { account_name, steam_username, steam_password, games_list, rental_price_per_day, description_az, description_en, description_ru } = req.body;
  const id = uuidv4();
  run('INSERT INTO steam_accounts VALUES (?,?,?,?,?,?,?,?,?,?,?,?,datetime("now"))',
    [id, account_name, steam_username, steam_password, games_list||'', rental_price_per_day||0, 1, description_az||'', description_en||'', description_ru||'', null, null]);
  res.json({ id, message: 'Hesab əlavə edildi' });
});

app.put('/api/accounts/:id', adminAuth, (req, res) => {
  const { account_name, games_list, rental_price_per_day, description_az, description_en, description_ru, is_available } = req.body;
  run('UPDATE steam_accounts SET account_name=?,games_list=?,rental_price_per_day=?,description_az=?,description_en=?,description_ru=?,is_available=? WHERE id=?',
    [account_name, games_list, rental_price_per_day, description_az, description_en, description_ru, is_available, req.params.id]);
  res.json({ message: 'Yeniləndi' });
});

app.get('/api/cart', auth, (req, res) => {
  const items = all('SELECT * FROM cart WHERE user_id=?', [req.user.id]);
  const enriched = items.map(item => {
    if (item.item_type === 'game' || item.item_type === 'game_rental') {
      return { ...item, details: get('SELECT * FROM games WHERE id=?', [item.item_id]) };
    }
    return { ...item, details: get('SELECT id,account_name,games_list,rental_price_per_day,description_az FROM steam_accounts WHERE id=?', [item.item_id]) };
  });
  res.json(enriched);
});

app.post('/api/cart', auth, (req, res) => {
  const { item_id, item_type, rental_days } = req.body;
  if (get('SELECT id FROM cart WHERE user_id=? AND item_id=? AND item_type=?', [req.user.id, item_id, item_type]))
    return res.status(400).json({ error: 'Artıq səbətdədir' });
  run('INSERT INTO cart VALUES (?,?,?,?,?)', [uuidv4(), req.user.id, item_id, item_type, rental_days || 1]);
  res.json({ message: 'Səbətə əlavə edildi' });
});

app.put('/api/cart/:id', auth, (req, res) => {
  run('UPDATE cart SET rental_days=? WHERE id=? AND user_id=?', [req.body.rental_days, req.params.id, req.user.id]);
  res.json({ message: 'Yeniləndi' });
});

app.delete('/api/cart/:id', auth, (req, res) => {
  run('DELETE FROM cart WHERE id=? AND user_id=?', [req.params.id, req.user.id]);
  res.json({ message: 'Silindi' });
});

app.post('/api/checkout', auth, (req, res) => {
  const cartItems = all('SELECT * FROM cart WHERE user_id=?', [req.user.id]);
  if (!cartItems.length) return res.status(400).json({ error: 'Səbət boşdur' });
  const user = get('SELECT * FROM users WHERE id=?', [req.user.id]);
  let total = 0;
  const orderData = [];
  const codes = [];

  for (const item of cartItems) {
    if (item.item_type === 'game') {
      const game = get('SELECT * FROM games WHERE id=?', [item.item_id]);
      if (!game) continue;
      total += parseFloat(game.price);
      orderData.push({ type: 'game_purchase', item_id: item.item_id, title: game.title, amount: parseFloat(game.price), rental_days: null });
    } else if (item.item_type === 'game_rental') {
      const game = get('SELECT * FROM games WHERE id=?', [item.item_id]);
      if (!game) continue;
      const cost = parseFloat(game.rental_price_per_day) * item.rental_days;
      total += cost;
      orderData.push({ type: 'game_rental', item_id: item.item_id, title: game.title, amount: cost, rental_days: item.rental_days });
    } else {
      const acc = get('SELECT * FROM steam_accounts WHERE id=?', [item.item_id]);
      if (!acc || !acc.is_available) continue;
      const cost = parseFloat(acc.rental_price_per_day) * item.rental_days;
      total += cost;
      orderData.push({ type: 'account_rental', item_id: item.item_id, title: acc.account_name, amount: cost, rental_days: item.rental_days, acc });
    }
  }

  total = Math.round(total * 100) / 100;
  const userBalance = parseFloat(user.balance) || 0;
  if (userBalance < total) return res.status(400).json({ error: `Balans kifayət deyil. Lazım: ${total} ₼, Mövcud: ${userBalance.toFixed(2)} ₼` });

  run('UPDATE users SET balance=balance-? WHERE id=?', [total, req.user.id]);

  orderData.forEach(o => {
    run('INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,datetime("now"))',
      [uuidv4(), req.user.id, o.type, o.item_id, o.title, o.amount, o.rental_days, 'completed']);
    if (o.type === 'account_rental') {
      const code = 'FG-' + Math.random().toString(36).substr(2, 4).toUpperCase() + '-' + Math.random().toString(36).substr(2, 4).toUpperCase();
      const rentalEnd = new Date(Date.now() + o.rental_days * 24 * 60 * 60 * 1000).toISOString();
      run('INSERT INTO customer_codes VALUES (?,?,?,?,?,?,?,datetime("now"),?,0,datetime("now"))',
        [uuidv4(), code, req.user.id, o.item_id, null, 'account_rental', o.rental_days, rentalEnd]);
      run('UPDATE steam_accounts SET is_available=0, current_renter_id=?, rental_end_time=? WHERE id=?',
        [req.user.id, rentalEnd, o.item_id]);
      codes.push({ title: o.title, code, rental_end: rentalEnd });
    }
  });

  run('DELETE FROM cart WHERE user_id=?', [req.user.id]);

  const codesHtml = codes.map(c => `<div style="background:#1a1a2e;border:2px solid #cc0000;border-radius:8px;padding:20px;margin:10px 0">
    <h3 style="color:#ff4444;margin:0 0 10px">${c.title}</h3>
    <div style="font-size:24px;font-weight:bold;color:#fff;letter-spacing:4px">${c.code}</div>
    <p style="color:#999;margin:5px 0 0">Bitmə: ${new Date(c.rental_end).toLocaleString('az-AZ')}</p>
  </div>`).join('');

  sendEmail(user.email, '✅ Sifariş Təsdiqləndi - Fantasy Game Store', emailTemplate('Sifarişiniz Hazırdır!',
    `<h2>Sifariş tamamlandı! 🎮</h2><p>Cəmi: <strong style="color:#cc0000">${total} ₼</strong></p>${codesHtml}`));
  sendEmail(CONFIG.BUSINESS_EMAIL, '🛒 Yeni Sifariş', emailTemplate('Yeni Sifariş',
    `<h2>Yeni sifariş!</h2><p>Müştəri: ${user.username} (${user.email})</p><p>Məbləğ: ${total} ₼</p>`));

  res.json({ message: 'Sifariş tamamlandı!', total, codes });
});

app.get('/api/orders', auth, (req, res) => {
  res.json(all('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC', [req.user.id]));
});

app.get('/api/my-rentals', auth, (req, res) => {
  res.json(all('SELECT c.*, s.account_name, s.games_list FROM customer_codes c LEFT JOIN steam_accounts s ON c.account_id=s.id WHERE c.user_id=? ORDER BY c.created_at DESC', [req.user.id]));
});

app.post('/api/use-code', auth, (req, res) => {
  const codeData = get('SELECT * FROM customer_codes WHERE code=? AND user_id=?', [req.body.code, req.user.id]);
  if (!codeData) return res.status(404).json({ error: 'Kod tapılmadı' });
  if (new Date(codeData.rental_end) < new Date()) return res.status(400).json({ error: 'Müddət bitib' });
  const account = get('SELECT account_name,steam_username,games_list FROM steam_accounts WHERE id=?', [codeData.account_id]);
  res.json({ account_name: account?.account_name, steam_username: account?.steam_username, games_list: account?.games_list, rental_end: codeData.rental_end });
});

app.get('/api/steam-code/:accountId', auth, async (req, res) => {
  const rental = get('SELECT * FROM customer_codes WHERE account_id=? AND user_id=? AND type="account_rental"', [req.params.accountId, req.user.id]);
  if (!rental) return res.status(403).json({ error: 'Giriş hüququ yoxdur' });
  if (new Date(rental.rental_end) < new Date()) return res.status(400).json({ error: 'Müddət bitib' });
  const cached = get('SELECT * FROM steam_codes_cache WHERE account_id=? AND is_delivered=0', [req.params.accountId]);
  if (cached) {
    run('UPDATE steam_codes_cache SET is_delivered=1 WHERE id=?', [cached.id]);
    return res.json({ code: cached.code, source: 'cache' });
  }
  const code = await fetchSteamCode(req.params.accountId);
  if (code) res.json({ code, source: 'imap' });
  else res.json({ code: null, message: 'Kod hələ gəlməyib. Steam-ə giriş cəhdi edin, sonra yenidən sınayın.' });
});

app.get('/api/payment-info', (req, res) => {
  res.json({ bank_name: CONFIG.BANK_NAME, card_number: CONFIG.CARD_NUMBER, card_owner: CONFIG.CARD_OWNER });
});

app.post('/api/balance-request', auth, upload.single('receipt'), (req, res) => {
  const { amount } = req.body;
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Məbləğ daxil edin' });
  if (!req.file) return res.status(400).json({ error: 'Çek faylı tələb olunur' });
  const id = uuidv4();
  const user = get('SELECT * FROM users WHERE id=?', [req.user.id]);
  run('INSERT INTO balance_requests VALUES (?,?,?,?,?,?,datetime("now"))',
    [id, req.user.id, parseFloat(amount), req.file.filename, 'pending', null]);
  sendEmail(CONFIG.BUSINESS_EMAIL, '💰 Yeni Balans Sorğusu', emailTemplate('Balans Sorğusu',
    `<h2>Yeni ödəniş sorğusu!</h2><p>Müştəri: ${user.username}</p><p>Məbləğ: ${amount} ₼</p><p>Çek yüklənib. Admin paneldən yoxlayın.</p>`));
  res.json({ message: 'Göndərildi. Admin təsdiqləyəndən sonra balansınız artacaq.' });
});

app.get('/api/balance-requests', auth, (req, res) => {
  res.json(all('SELECT * FROM balance_requests WHERE user_id=? ORDER BY created_at DESC', [req.user.id]));
});

app.put('/api/admin/balance-request/:id', adminAuth, (req, res) => {
  const { status, admin_note } = req.body;
  const request = get('SELECT * FROM balance_requests WHERE id=?', [req.params.id]);
  if (!request) return res.status(404).json({ error: 'Tapılmadı' });
  run('UPDATE balance_requests SET status=?, admin_note=? WHERE id=?', [status, admin_note, req.params.id]);
  if (status === 'approved') {
    run('UPDATE users SET balance=balance+? WHERE id=?', [request.amount, request.user_id]);
    const u = get('SELECT * FROM users WHERE id=?', [request.user_id]);
    sendEmail(u.email, '✅ Balansınız Artırıldı', emailTemplate('Balans Artırıldı',
      `<h2>Ödənişiniz təsdiqləndi! 🎉</h2><p>${request.amount} ₼ balansınıza əlavə edildi.</p>`));
  } else {
    const u = get('SELECT * FROM users WHERE id=?', [request.user_id]);
    sendEmail(u.email, '❌ Ödəniş Rədd Edildi', emailTemplate('Rədd Edildi',
      `<h2>Ödənişiniz rədd edildi</h2><p>Səbəb: ${admin_note || 'Çek doğrulanmadı'}</p>`));
  }
  res.json({ message: status === 'approved' ? 'Təsdiqləndi' : 'Rədd edildi' });
});

app.get('/api/admin/users', adminAuth, (req, res) => {
  res.json(all('SELECT id,username,email,role,balance,created_at FROM users ORDER BY created_at DESC'));
});

app.get('/api/admin/orders', adminAuth, (req, res) => {
  res.json(all('SELECT o.*, u.username, u.email FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC'));
});

app.get('/api/admin/balance-requests', adminAuth, (req, res) => {
  res.json(all('SELECT b.*, u.username, u.email FROM balance_requests b JOIN users u ON b.user_id=u.id ORDER BY b.created_at DESC'));
});

app.get('/api/admin/rentals', adminAuth, (req, res) => {
  res.json(all('SELECT c.*, u.username, u.email, s.account_name FROM customer_codes c JOIN users u ON c.user_id=u.id LEFT JOIN steam_accounts s ON c.account_id=s.id ORDER BY c.created_at DESC'));
});

app.get('/api/admin/accounts-all', adminAuth, (req, res) => {
  res.json(all('SELECT id,account_name,steam_username,games_list,rental_price_per_day,is_available,rental_end_time FROM steam_accounts ORDER BY created_at DESC'));
});

app.get('/api/admin/stats', adminAuth, (req, res) => {
  res.json({
    totalUsers: (get('SELECT COUNT(*) as c FROM users WHERE role="user"') || {}).c || 0,
    totalOrders: (get('SELECT COUNT(*) as c FROM orders') || {}).c || 0,
    totalRevenue: parseFloat((get('SELECT SUM(amount) as s FROM orders WHERE status="completed"') || {}).s) || 0,
    pendingPayments: (get('SELECT COUNT(*) as c FROM balance_requests WHERE status="pending"') || {}).c || 0,
    activeRentals: (get('SELECT COUNT(*) as c FROM customer_codes WHERE rental_end > datetime("now")') || {}).c || 0,
  });
});

// Cron - check rentals every 5 min
cron.schedule('*/5 * * * *', () => {
  const now = new Date().toISOString();

  // 24h warning
  const oneDayAhead = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  const oneDayMin = new Date(Date.now() + 23 * 60 * 60 * 1000).toISOString();
  const warns24 = all('SELECT c.*, u.email, u.username, s.account_name FROM customer_codes c JOIN users u ON c.user_id=u.id LEFT JOIN steam_accounts s ON c.account_id=s.id WHERE c.type="account_rental" AND c.rental_end BETWEEN ? AND ?', [oneDayMin, oneDayAhead]);
  warns24.forEach(r => sendEmail(r.email, '⚠️ Kirayə 24 saata bitir', emailTemplate('24 Saat Qaldı',
    `<h2>Kirayəniz tezliklə bitir ⏰</h2><p>${r.account_name} hesabının kirayəsi 24 saata bitir.</p>`)));

  // 10 min warning
  const tenMin = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  const nineMin = new Date(Date.now() + 9 * 60 * 1000).toISOString();
  const warns10 = all('SELECT c.*, u.email, u.username, s.account_name FROM customer_codes c JOIN users u ON c.user_id=u.id LEFT JOIN steam_accounts s ON c.account_id=s.id WHERE c.type="account_rental" AND c.rental_end BETWEEN ? AND ?', [nineMin, tenMin]);
  warns10.forEach(r => {
    sendEmail(r.email, '🚨 10 DƏQİQƏ QALDI!', emailTemplate('Təcili',
      `<h2 style="color:#ff4444">⚠️ 10 Dəqiqə Qaldı!</h2><p>${r.account_name} kirayəniz 10 dəqiqəyə bitir!</p>`));
    sendEmail(CONFIG.BUSINESS_EMAIL, `⚠️ Kirayə bitiyor: ${r.account_name}`, emailTemplate('Kirayə Bitmə',
      `<h2>10 dəq qaldı: ${r.account_name}</h2><p>Müştəri: ${r.username}</p><p style="color:#ff8800">Steam şifrəsini dəyişməyə hazır olun!</p>`));
  });

  // Free expired
  const expired = all('SELECT * FROM steam_accounts WHERE is_available=0 AND rental_end_time < ?', [now]);
  expired.forEach(acc => {
    run('UPDATE steam_accounts SET is_available=1, current_renter_id=NULL, rental_end_time=NULL WHERE id=?', [acc.id]);
    sendEmail(CONFIG.BUSINESS_EMAIL, `🔓 Hesab azad oldu: ${acc.account_name}`, emailTemplate('Hesab Azad Oldu',
      `<h2>${acc.account_name} azad oldu</h2><p style="color:#ff8800">Steam şifrəsini dəyişməyi unutmayın!</p>`));
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

initDb().then(() => {
  app.listen(PORT, () => {
    console.log(`\n╔══════════════════════════════════════╗`);
    console.log(`║   🎮 Fantasy Game Store Backend     ║`);
    console.log(`║   URL: http://localhost:${PORT}          ║`);
    console.log(`║   Admin: ${CONFIG.BUSINESS_EMAIL.substring(0,20)}...   ║`);
    console.log(`╚══════════════════════════════════════╝\n`);
  });
}).catch(console.error);
