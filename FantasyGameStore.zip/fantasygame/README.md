# 🎮 Fantasy Game Store

Steam oyun satışı və hesab kirayəsi platformu.

---

## ⚡ Sürətli Başlanğıc

### 1. Email Konfiqurasiyası

`backend/.env.example` faylını `backend/.env` adı ilə kopyalayın:
```
cp backend/.env.example backend/.env
```

`.env` faylını açıb doldurun:
- `BUSINESS_EMAIL` — sizin Gmail (bildirişlər üçün)
- `BUSINESS_EMAIL_PASSWORD` — Gmail App Password (aşağıda izah var)
- `STEAM_IMAP_EMAIL` — Steam-in bağlı olduğu Gmail
- `STEAM_IMAP_PASSWORD` — həmin Gmail-in App Password
- `WHATSAPP_NUMBER` — 994505786977 formatında
- `BANK_NAME`, `CARD_NUMBER`, `CARD_OWNER` — bank məlumatları

### 2. Gmail App Password Necə Alınır?

1. Gmail → Sağ üst profil → Google Hesabı
2. Təhlükəsizlik → 2 Addımlı Doğrulama (aktiv edin)
3. Axtarış → "App passwords"
4. "Mail" + "Other" seçin → Kod kopyalayın
5. `.env` faylına yapışdırın

### 3. Railway-də Yerləşdirmə

1. [railway.app](https://railway.app) → GitHub ilə qeydiyyat
2. "New Project" → "Deploy from GitHub repo"
3. Bu qovluğu GitHub-a yükləyin
4. Railway-də "Variables" bölməsindən `.env` məlumatlarını daxil edin
5. Deploy → Hazır!

---

## 👑 Admin Girişi

```
Email: .env-dəki BUSINESS_EMAIL
Şifrə: admin123  ← DƏYİŞİN!
URL: sizinsayt.railway.app/  → Admin menyu
```

**Admin şifrəsini dəyişmək üçün:**
Sayta daxil olun → Admin Panel → İstifadəçilər

---

## 🔧 Yerli Test (Local)

```bash
cd backend
npm install
node server.js
```

Brauzer: http://localhost:3001

---

## 📋 Funksiyalar

### Müştərilər üçün:
- ✅ Qeydiyyat / Giriş
- ✅ Oyun alışı
- ✅ Oyun kirayəsi
- ✅ Steam hesab kirayəsi
- ✅ Müştəri kodu sistemi
- ✅ Steam doğrulama kodu (IMAP)
- ✅ Balans sistemi (çek yükləmə)
- ✅ 3 dil (AZ/EN/RU)
- ✅ Qaranlıq/Açıq tema
- ✅ Email bildirişlər

### Admin üçün:
- ✅ Ödəniş təsdiqi/rəddi
- ✅ Aktiv kirayələr izlənməsi
- ✅ Vaxt bitmə bildirişləri
- ✅ Oyun əlavə et/sil/redaktə
- ✅ Hesab əlavə et
- ✅ İstifadəçi idarəetməsi
- ✅ Gəlir statistikası

---

## ⚠️ Vacib Qeydlər

1. **Admin şifrəsini dəyişin** — ilk girişdən sonra
2. **JWT_SECRET dəyişin** — `.env` faylında
3. **Çek faylları** — `backend/uploads/` qovluğunda saxlanır
4. **Steam şifrəsi** — kirayə bitəndə özünüz dəyişin (sistem sizi xəbərdar edir)

---

## 📞 Dəstək

WhatsApp: +994505786977
